/**
 * 
 */
package co.edu.poli.automatas.proyecto.exception;

/**
 * @author Luis Castillo
 *
 */
public class InvalidArgumentException extends Exception {

	public InvalidArgumentException(String string) {
		super(string);
	}

	/** **/
	private static final long serialVersionUID = 1L;

}
