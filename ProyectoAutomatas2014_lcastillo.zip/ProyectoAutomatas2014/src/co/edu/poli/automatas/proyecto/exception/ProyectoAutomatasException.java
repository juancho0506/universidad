/**
 * 
 */
package co.edu.poli.automatas.proyecto.exception;

/**
 * @author Luis Castillo
 *
 */
public class ProyectoAutomatasException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param arg0
	 */
	public ProyectoAutomatasException(String arg0) {
		super(arg0);
	}

}
